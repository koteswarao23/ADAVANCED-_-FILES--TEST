#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int find_lines(FILE *fp)
{
        int l;
        while(*fp->_IO_read_ptr++)
        {
                if(*fp->_IO_read_ptr=='\n')
                        l++;
        }
        return l;
}

int print_fristline(int pos1,FILE *head)
{
        fseek(head,pos1,0);

        while(*head->_IO_read_ptr!='\n')
        {
                printf("%c", *head->_IO_read_ptr++);
                pos1++;

        }
        printf("\n");

        return pos1+1;


}

int print_lastline(int pos2,FILE *tail)
{
        fseek(tail,-pos2-1,2);
        int i,k;
        while(*--tail->_IO_read_ptr != '\n')
        {
                //printf("%c",*fp->_IO_read_ptr);
                pos2++;
        }

        while(*++tail->_IO_read_ptr!='\n')
        {
                printf("%c",*tail->_IO_read_ptr);
        }
        printf("\n");
        return ++pos2;

}


int main(int arg ,char **argc)
{

        if(arg<2)
        {
                printf("input format: ./a.out  filename\n");
                exit(0);
        }
        
        FILE *head,*tail;
        int pos1=0,pos2=0;
        head=fopen(argc[1],"r");
        tail=fopen(argc[1],"r");
        if(head ==NULL  || tail==NULL)
        {
                perror("fopen");
                exit(0);
        }
        fgetc(head);
        getc(tail);

        int L= find_lines(head);
        fseek(head,0,0);
        fseek(tail,0,0);
        int t=0;

        while(t!=L/2)
        {
                pos1=print_fristline(pos1,head);
                pos2=print_lastline(pos2,tail);
                t++;
        }

        if(L%2==1)
                pos1=print_fristline(pos1,head);

}                     
     
     
     
     
             